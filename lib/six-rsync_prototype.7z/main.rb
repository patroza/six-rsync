require 'six/rsync'
module Six
  module Rsync
    sync_remote('rsync://git.dev-heaven.net/rel/caa1', 'C:/temp/temp')
  end
end
