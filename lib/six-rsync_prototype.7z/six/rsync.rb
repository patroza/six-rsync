module Six
  module Rsync
    BASE_PATH = Dir.pwd
    TOOLS_PATH = File.join(BASE_PATH, 'tools')
    FOLDER = /(.*)\/(.*)/
    ENV['PATH'] = ENV['PATH'] + ";#{TOOLS_PATH}"

    module_function

    def command(params, host, path)
      path[FOLDER]
      folder, repos = $1, $2
      Dir.chdir folder
      system "rsync.exe #{params} #{host} #{repos}"
    end

    def sync_remote(host, path)
      command("-a --progress", host, path)
    end
  end
end

